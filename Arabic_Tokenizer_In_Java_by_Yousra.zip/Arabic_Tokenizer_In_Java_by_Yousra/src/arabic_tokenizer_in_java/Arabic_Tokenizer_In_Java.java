/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arabic_tokenizer_in_java;

/**
 *
 * -
 * @author Yousra
 */

import com.qcri.farasa.segmenter.Farasa;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner; 
public class Arabic_Tokenizer_In_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException{
        
        /*HttpResponse response = Unirest.post(“https://farasa-api.qcri.org/msa/webapi/segmenter”).header(“content-type”, “application/json”) .header(“cache-control”, “no-cache”) .body(“{\”text\”: \”هذا مثال بسيط\”}”) .asString();
        */
        
        Farasa farasa = new Farasa();
        String arabicInput="السلام عليكم و رحمة الله و بركاته";
        //Scanner sc = new Scanner(System.in,  "UTF-8");
        //arabicInput= sc.nextLine();
        
        ArrayList<String> output = farasa.segmentLine(arabicInput);
                for(String s: output)
                System.out.println(s); 
    }
    
}
